package it.unimore.fum.iot.Interfaces;

public interface Sensor {

    int generateNumVeicoliPassaggio();
    String [] generateTarghe(int numtarghe);
    int generateNumPersonePassaggio();
    int generateNumBiciclettePassaggio();
    int generateNumVeicolifermi();

}
