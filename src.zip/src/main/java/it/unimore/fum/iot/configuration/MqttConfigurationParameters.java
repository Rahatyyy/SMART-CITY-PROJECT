package it.unimore.fum.iot.configuration;

public class MqttConfigurationParameters {

    public static final String MQTT_USERNAME = "272841@studenti.unimore.it";
    public static final String MQTT_PASSWORD = "owicpdomttmdyycr";

    public static final String BROKER_ADDRESS = "155.185.228.20";
    public static final int BROKER_PORT = 7883;

}
