package it.unimore.fum.iot.Interfaces;

import it.unimore.fum.iot.models.Policy;

public interface Actuator {
    public void setpolicy(Policy policyNuova);
}
