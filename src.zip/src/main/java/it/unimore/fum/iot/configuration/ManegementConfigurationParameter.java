 package it.unimore.fum.iot.configuration;

public class ManegementConfigurationParameter {
    public static final int MAX_NUM_OGGETTI =20;
    public static final int NUM_MACCHINE_CONGESTIONE=10;
    public static final int NUM_ITERAZIONI_SMART_CAMERA=4;
    public static final int SECONDI_AGGIORNAMENTO= 5;
    public static final int PROBABILITA_TARGA_MONITORATA=3;
    public static final int NUM_DISPOSITIVI=5;
}
